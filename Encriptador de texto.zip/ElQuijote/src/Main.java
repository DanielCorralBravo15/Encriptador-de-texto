import java.io.*;
import java.util.*;

class ContadorLetrasYEncriptacion {
    public static void main(String[] args) {
        try {
            String nombreArchivoEntrada = obtenerNombreArchivo("Por favor, ingrese el nombre del archivo de entrada (.txt): ");
            FileReader archivo = new FileReader(nombreArchivoEntrada);
            BufferedReader lector = new BufferedReader(archivo);
            StringBuilder contenido = new StringBuilder();
            String linea;
            while ((linea = lector.readLine()) != null) {
                contenido.append(linea);
            }
            lector.close();

            PipedOutputStream outputStream = new PipedOutputStream();
            PipedInputStream frequencyInputStream = new PipedInputStream(outputStream);
            PipedOutputStream encryptedTextOutputStream = new PipedOutputStream();
            PipedInputStream writerInputStream = new PipedInputStream(encryptedTextOutputStream);

            Map<Character, Integer> frecuenciaLetras = new HashMap<>();
            Thread frecuenciaThread = new Thread(() -> contarLetras(frequencyInputStream, frecuenciaLetras));
            frecuenciaThread.start();

            Thread escrituraThread = new Thread(() -> {
                try {
                    encriptarYGuardar(contenido.toString(), encryptedTextOutputStream);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            escrituraThread.start();

            boolean salir = false;
            Scanner scanner = new Scanner(System.in);

            while (!salir) {
                System.out.println("1. Mostrar la lista de letras");
                System.out.println("2. Encriptar el texto");
                System.out.println("3. Desencriptar el texto");
                System.out.println("4. Contar ocurrencias de una cadena");
                System.out.println("5. Salir");
                System.out.print("Seleccione una opción: ");
                int opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1:
                        try {
                            frecuenciaThread.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        mostrarListaLetras(frecuenciaLetras);
                        break;
                    case 2:
                        encriptarYGuardar(contenido.toString(), encryptedTextOutputStream);
                        break;
                    case 3:
                        System.out.print("Ingrese el valor 0 para desencriptar: ");
                        int desplazamientoDesencriptar = scanner.nextInt();
                        scanner.nextLine();
                        String textoDesencriptado = desencriptarTexto(contenido.toString(), desplazamientoDesencriptar);
                        String nombreArchivoSalidaDesencriptado = obtenerNombreArchivo("Por favor, ingrese el nombre del archivo de salida para el texto desencriptado (.txt): ");
                        guardarTextoEnArchivo(textoDesencriptado, nombreArchivoSalidaDesencriptado);
                        System.out.println("Texto desencriptado guardado en " + nombreArchivoSalidaDesencriptado);
                        break;
                    case 4:
                        System.out.print("Ingrese la cadena de caracteres a buscar en el archivo: ");
                        String cadenaBusqueda = scanner.nextLine();
                        int ocurrencias = contarOcurrencias(contenido.toString(), cadenaBusqueda);
                        System.out.println("La cadena \"" + cadenaBusqueda + "\" aparece " + ocurrencias + " veces en el archivo.");
                        break;
                    case 5:
                        salir = true;
                        break;
                    default:
                        System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
                }
            }

            try {
                frecuenciaThread.join();
                escrituraThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String obtenerNombreArchivo(String mensaje) {
        Scanner scanner = new Scanner(System.in);
        String nombreArchivo;
        do {
            System.out.print(mensaje);
            nombreArchivo = scanner.nextLine();
            if (!nombreArchivo.toLowerCase().endsWith(".txt")) {
                System.out.println("El archivo debe tener la extensión .txt");
            }
        } while (!nombreArchivo.toLowerCase().endsWith(".txt"));
        return nombreArchivo;
    }

    private static void guardarTextoEnArchivo(String texto, String nombreArchivo) throws IOException {
        FileWriter escritor = new FileWriter(nombreArchivo);
        BufferedWriter bufferedWriter = new BufferedWriter(escritor);
        bufferedWriter.write(texto);
        bufferedWriter.close();
    }

    public static void contarLetras(InputStream inputStream, Map<Character, Integer> frecuenciaLetras) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            int c;
            while ((c = reader.read()) != -1) {
                char caracter = (char) c;
                if (Character.isLetter(caracter)) {
                    caracter = Character.toLowerCase(caracter);
                    frecuenciaLetras.put(caracter, frecuenciaLetras.getOrDefault(caracter, 0) + 1);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void mostrarListaLetras(Map<Character, Integer> frecuenciaLetras) {
        System.out.println("Frecuencia de letras (ordenadas de mayor a menor):");
        List<Map.Entry<Character, Integer>> listaOrdenada = new ArrayList<>(frecuenciaLetras.entrySet());
        listaOrdenada.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));
        for (Map.Entry<Character, Integer> entry : listaOrdenada) {
            char letra = entry.getKey();
            int frecuencia = entry.getValue();
            System.out.println(letra + ": " + frecuencia);
        }
    }

    public static void encriptarYGuardar(String texto, OutputStream outputStream) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el valor de desplazamiento para encriptar: ");
        int desplazamientoEncriptar = scanner.nextInt();
        scanner.nextLine();
        String textoEncriptado = encriptarTexto(texto, desplazamientoEncriptar);
        guardarTextoEnTuberia(textoEncriptado, outputStream);
    }

    private static void guardarTextoEnTuberia(String texto, OutputStream outputStream) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream))) {
            writer.write(texto);
        }
    }

    public static String encriptarTexto(String texto, int desplazamiento) {
        StringBuilder resultado = new StringBuilder();
        for (char caracter : texto.toCharArray()) {
            if (Character.isLetter(caracter)) {
                char inicio = Character.isLowerCase(caracter) ? 'a' : 'A';
                caracter = (char) (inicio + (caracter - inicio + desplazamiento) % 26);
            }
            resultado.append(caracter);
        }
        return resultado.toString();
    }

    public static String desencriptarTexto(String texto, int desplazamiento) {
        return encriptarTexto(texto, 26 - (desplazamiento % 26));
    }

    public static int contarOcurrencias(String texto, String cadenaBusqueda) {
        int contador = 0;
        try {
            PushbackReader pushbackReader = new PushbackReader(new CharArrayReader(texto.toCharArray()));

            int c;
            int index = 0;

            while ((c = pushbackReader.read()) != -1) {
                char caracter = (char) c;

                if (caracter == cadenaBusqueda.charAt(index)) {
                    index++;

                    if (index == cadenaBusqueda.length()) {
                        contador++;
                        index = 0;
                    }
                } else {
                    pushbackReader.unread(cadenaBusqueda.substring(0, index).toCharArray());
                    index = 0;
                }
            }
            pushbackReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return contador;
    }
}